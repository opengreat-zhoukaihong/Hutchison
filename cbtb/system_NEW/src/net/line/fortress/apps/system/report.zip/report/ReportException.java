package net.line.fortress.apps.system.report;

public class ReportException extends java.lang.Exception
{

	public ReportException(String message) {
		super(message);
	}
}
